var searchData=
[
  ['copyright_309',['Copyright',['../page_copyright.html',1,'index']]]
];
